import greenfoot.*;


public class Araña extends Enemigo
{
   
    public void act()
    {
        moverseAleatoriamente();
        rotarAleatoriamente();
        verificarColisiones();
    }
    
    private void moverseAleatoriamente()
    {
        if (Greenfoot.getRandomNumber(100) < 2) // 2% de probabilidad
        {
            move(Greenfoot.getRandomNumber(11)); // Mover entre 0 a 10 pixeles
        }
    }
    
    private void rotarAleatoriamente()
    {
        if (Greenfoot.getRandomNumber(100) < 5) // 5% de probabilidad
        {
            turn(Greenfoot.getRandomNumber(361) - 180); // Rotar entre -180 a 180 grados
        }
    }
    
    private void verificarColisiones()
    {
        Actor mosca = getOneIntersectingObject(Mosca.class);
        if (mosca != null)
        {
            getWorld().removeObject(mosca); // Eliminar la mosca del mundo
            return; // Termina la ejecución para evitar realizar acciones adicionales en este ciclo
        }
        
        Actor abeja = getOneIntersectingObject(Abeja.class);
        if (abeja != null)
        {
            getWorld().removeObject(abeja); // Eliminar la abeja del mundo
            Greenfoot.stop(); // Terminar el juego
        }
    }
    
}
