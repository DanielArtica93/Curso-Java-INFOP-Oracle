import greenfoot.*;

public class Abeja extends Insecto
{
    public void act()
    {
        avanzar();
        rotar();
        choques();
        borrarBarraEspaciadora(); // Llama al método para borrar la mosca al presionar la barra espaciadora si está en el mundo
    } 
    
    private void avanzar()
    {
        move(1); // La abeja siempre avanza 1 pixel por frame o marco
    }
    
    private void rotar()
    {
        if (Greenfoot.isKeyDown("left")) // Si se presiona la tecla direccional izquierda
        {
            turn(-3); // Rota 3 grados a la izquierda
        }
        if (Greenfoot.isKeyDown("right")) // Si se presiona la tecla direccional derecha
        {
            turn(3); // Rota 3 grados a la derecha
        }
    }
}
