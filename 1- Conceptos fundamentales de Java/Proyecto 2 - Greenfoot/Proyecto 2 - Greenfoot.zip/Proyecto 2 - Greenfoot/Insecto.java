import greenfoot.*;

public class Insecto extends Actor
{
    public void act()
    {
        
    }
    
    public void choques()
    {
        if (isTouching(Mosca.class))
        {
            removeTouching(Mosca.class);
        }
    }
        
    public void borrarBarraEspaciadora()
    {
        // Verifica si se presiona la barra espaciadora
        if (Greenfoot.isKeyDown("space"))
        {
            // Verifica si hay al menos una mosca y una abeja en el mundo
            if (getWorld().getObjects(Mosca.class).size() > 0 && getWorld().getObjects(Abeja.class).size() > 0)
            {
                // Elimina solo una mosca en el mundo
                Mosca mosca = (Mosca)getWorld().getObjects(Mosca.class).get(0);
                getWorld().removeObject(mosca);
                
                // Asegurando de que el método no elimine más de una mosca hasta que se suelte la tecla
                Greenfoot.delay(10); // Retardo para evitar múltiples eliminaciones en una sola presión de tecla
            }
        }
    }
}
