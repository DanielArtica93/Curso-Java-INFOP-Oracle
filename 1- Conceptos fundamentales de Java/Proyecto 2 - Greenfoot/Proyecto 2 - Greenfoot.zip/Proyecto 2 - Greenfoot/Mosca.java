import greenfoot.*;

public class Mosca extends Insecto
{
    public void act()
    {
        // Genera un número aleatorio entre 0 y 100
        int CambiosAleatorios = Greenfoot.getRandomNumber(100);
        
        // Verifica si el número aleatorio está dentro del 10% de probabilidad
        if (CambiosAleatorios < 10) {
            // Genera un valor de avance aleatorio entre 0 y 20 píxeles
            int DistanciaAleatoria = Greenfoot.getRandomNumber(21);
        
            // Avanza el objeto por la distancia generada
            move(DistanciaAleatoria);
        }

        // Verifica si el número aleatorio está dentro del 5% de probabilidad
        if (CambiosAleatorios < 5) {
            // Genera un ángulo aleatorio entre -90 y 90 grados
            int randomAngle = Greenfoot.getRandomNumber(181) - 90;
        
            // Rota el objeto por el ángulo generado
            setRotation(getRotation() + randomAngle);
        }
      
    }
        
}