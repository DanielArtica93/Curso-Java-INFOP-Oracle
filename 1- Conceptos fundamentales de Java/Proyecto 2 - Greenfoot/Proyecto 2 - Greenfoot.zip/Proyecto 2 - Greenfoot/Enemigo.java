import greenfoot.*;

public class Enemigo extends Actor
{
    public void act()
    {
    
    }
}
