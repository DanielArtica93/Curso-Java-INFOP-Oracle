import greenfoot.*; 

public class MundoMesa extends World
{

    public MundoMesa()
    {    
        // Crea un nuevo mundo con celdas de 600x400 con un tamaño de celda de 1x1 píxeles.
        super(600, 400, 1); 
    }
}
